#!/bin/bash
#current path
path=$PWD

echo "Note: This script will run by using our method (ARCH)"
echo "which cl"
read cl

echo "Please Choose which case study want to run?"
echo "1: TAS case study"
echo "2: Online Shopping  case study"
read choose

##### to choose 
case $choose in
   1) Non="${2}"
   #create the observation folder
   mkdir $path/CaseStudies/TAS/non_unifrom
   java -jar $path/ObservationFiles/genFiles.jar 1 3000000 2020 $path/CaseStudies/TAS/non_unifrom
   #update the obs script in both case studies folder
   #perl -i -pe 'path='1' ;/ if $.==7' "$path"/CaseStudies/TAS/obs.sh
   #update configuration file
   #perl -i -pe 'NewObservationScriptLocation,'$path/CaseStudies/TAS/obs.sh' ;/ if $.==9' $path/Configuration.txt
   #run FACT2
java -jar $path/FACT2.jar $path/CaseStudies/TAS/TAS.pm $path/CaseStudies/TAS/TAS.pctl $cl

      ;;
   2) Uni="${2}"
      mkdir $path/CaseStudies/OnlineShopping/non_unifrom
      java -jar $path/ObservationFiles/genFiles.jar 1 3000000 2020 $path/non_unifrom
    #update the obs script in both case studies folder
   perl -i -pe 'path='1' ;/ if $.==7' $path/CaseStudies/TAS/obs.sh
   #update configuration file
   perl -i -pe 'NewObservationScriptLocation,'$path/CaseStudies/OnlineShopping/obs.sh' ;/ if $.==9' $path/Configuration.txt
   #run FACT2
   java -jar $path/FACT2.jar $path/CaseStudies/OnlineShopping/shopping.pm $path/CaseStudies/OnlineShopping/shopping.pctl $cl
CaseStudies/OnlineShopping/shopping.pm 
;;
   *)
      echo "Please insert either 1 or 2"
      exit 1 # Command to come out of the program with status 1
      ;;
esac


echo "DONE!"
