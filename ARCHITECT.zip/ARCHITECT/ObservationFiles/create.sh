#!/bin/bash
echo "Please how many observation files do you want to create? (e.g., 10)"
read obsFile
echo "What is the maximum value of binaray inside the file? (e.g., 300000)"
read numValue
echo "What is the number for seed? (e.g., 2050)"
read seed
jar=genFiles.jar
path=$PWD
mkdir $path/non_unifrom
mkdir $path/unifrom
#java -jar <jarFile> <number of Files> <numValue> <seed> <output path>
java -jar $jar $obsFile $numValue $seed non_unifrom
java -jar $jar $obsFile $numValue $seed unifrom
path1=$path/non_unifrom
path2=$path/unifrom
echo " ">> paths.txt
echo "Obsrvation Files for non_uniform:" >> paths.txt
echo $path1 >> paths.txt
echo " ">> paths.txt
echo "Obsrvation Files for uniform:" >> paths.txt
echo $path2 >> paths.txt

echo "DONE!"