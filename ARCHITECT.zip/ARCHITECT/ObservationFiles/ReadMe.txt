To get the randomValues Files
- go to terminal
- cd to current folder "ObsrvationFiles"
- write on terminal ./create.sh
- follow the appeared instructions.
- two folders will be created contains the randomValues Files.
- paths.txt file will created contains the required paths