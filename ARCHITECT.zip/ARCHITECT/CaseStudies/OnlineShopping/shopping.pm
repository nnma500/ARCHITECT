dtmc
label "wfSUCC" = (s=16);
label "wfFAIL" = (s=15)|(s=5)|(s=13)|(s=8);

param pAuthSUCC : observations = 1 1 ; component = 1 ; cost = 3.7 ;
param pNormShippingSUCC : observations = 1 1 ; component = 2 ; cost = 4.4 ;
param pExpShippingSUCC : observations = 1 1 ; component = 3 ; cost = 2.6 ;
param pPaymentSUCC : observations = 1 1 ; component = 4 ; cost = 1.5 ;

const double p_RETURNBUY_SEARCH = 0.2;
const double p_RETURNBUY_EXPRESS = 0.5;
const double p_RETURNBUY_NORMAL = 0.3;


const double p_NEWBUY_SEARCH = 0.15;
const double p_NEWBUY_EXPRESS = 0.25;
const double p_NEWBUY_NORMAL = 0.6;

const double p_PROFILER_NEW = 0.65;
const double p_PROFILER_RETURN = 0.35;

module ecommercewf
s : [0..16] init 0;

//authentication service invocation (login)
[](s=0) -> (pAuthSUCC1):(s'=2) + (1-pAuthSUCC1):(s'=5);
[] (s=5) -> true;//absorbing state modelling login failure
 
//paritioning of new/returning customers.
[] (s=2) -> p_PROFILER_NEW:(s'=1) + p_PROFILER_RETURN:(s'=3);

[] (s=1) -> 1:(s'=4);
[] (s=4) -> 1:(s'=7);
[] (s=3) -> 1:(s'=6);
[] (s=6) -> 1:(s'=9);

//choice between shipping method or continuing search (returning user)
[] (s=7) -> p_RETURNBUY_SEARCH:(s'=4)+p_RETURNBUY_EXPRESS:(s'=10)+p_RETURNBUY_NORMAL:(s'=12);

//choice between shipping method or continung search (new user)
[] (s=9) -> p_NEWBUY_EXPRESS:(s'=10) + p_NEWBUY_NORMAL:(s'=12) + p_NEWBUY_SEARCH:(s'=9);


//Shipping service invocation (express)
[] (s=10) -> (pExpShippingSUCC1):(s'=11) + (1-pExpShippingSUCC1):(s'=13);
[] (s=13) -> true;//express shipping failure
 

//Shipping service invocation (normal)
[] (s=12) -> (pNormShippingSUCC1):(s'=11) + (1-pNormShippingSUCC1):(s'=15);
[] (s=15) -> true;//normal shipping failure

 
//authentication service invocation (logout)
[] (s=14) -> (pAuthSUCC1):(s'=16)+(1-pAuthSUCC1):(s'=5);
[] (s=16) -> true;//absorbing state modelling logout success
 

//payment service invocation (payment)
[] (s=11) -> (pPaymentSUCC1):(s'=14) + (1-pPaymentSUCC1):(s'=8);
[](s=8) -> true;//payment failure

endmodule

//costs of services
rewards
(s=0)  : 1;   //authentication service
(s=10) : 1;   //express shipping
(s=11) : 1;   //payment
(s=12) : 1;   //normal shipping
(s=14) : 1;   //authentication (logout)
endrewards
