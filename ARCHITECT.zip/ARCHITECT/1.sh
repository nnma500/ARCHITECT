#!/bin/bash
#current path
path=$PWD

cat $path/CaseStudies/TAS/obs.sh > obs111.sh
