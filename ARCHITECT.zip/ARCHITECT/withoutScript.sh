#!/bin/bash
#current path
path=$PWD
echo "which cl"
read cl
echo "Please Choose which case study want to run?"
echo "1: TAS case study"
echo "2: Online Shopping  case study"
read choose

##### to choose 
case $choose in
   1) Non="${2}"
java -jar $path/FACT2.jar $path/CaseStudies/TAS/TAS.pm $path/CaseStudies/TAS/TAS.pctl $cl

      ;;
   2) Uni="${2}"
   java -jar $path/FACT2.jar $path/CaseStudies/OnlineShopping/shopping.pm $path/CaseStudies/OnlineShopping/shopping.pctl $cl
CaseStudies/OnlineShopping/shopping.pm 
;;
   *)
      echo "Please insert either 1 or 2"
      exit 1 # Command to come out of the program with status 1
      ;;
esac


echo "DONE!"